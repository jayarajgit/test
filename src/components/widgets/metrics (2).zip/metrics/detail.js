(function() {
	'use strict';

	angular.module(HygieiaConfig.module).controller('MetricsDetailController',
			MetricsDetailController);

	MetricsDetailController.$inject = [ '$modalInstance', '$scope', '$filter',
			'NgTableParams' ];
	function MetricsDetailController($modalInstance, $scope,$filter,  NgTableParams) {
		/*jshint validthis:true */
		var ctrl = this;
		ctrl.metricsData = [

		{
			"serviceName" : "E2Ei",
			"methodName" : "getGCHProfiles",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "GCH",
			"count" : "10",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}, {
			"serviceName" : "E2Ei",
			"methodName" : "getCLINList",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "VECRM",
			"count" : "20",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}, {
			"serviceName" : "E2Ei",
			"methodName" : "getGCHProfileDetails",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "PQ",
			"count" : "30",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}, {
			"serviceName" : "E2Ei",
			"methodName" : "getGCHProfileDetails",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "PQ",
			"count" : "30",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}, {
			"serviceName" : "E2Ei",
			"methodName" : "getGCHProfileDetails",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "PQ",
			"count" : "30",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}, {
			"serviceName" : "E2Ei",
			"methodName" : "getGCHProfileDetails",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "PQ",
			"count" : "30",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}, {
			"serviceName" : "E2Ei",
			"methodName" : "getGCHProfileDetails",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "PQ",
			"count" : "30",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}, {
			"serviceName" : "E2Ei",
			"methodName" : "getGCHProfileDetails",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "PQ",
			"count" : "30",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}

		];
		$scope.data = ctrl.metricsData;
		ctrl.totalNoTransPerPage = 0;
		ctrl.totalNoTrans = 0;
		ctrl.env = "N/A";
		ctrl.title = "";
		ctrl.metricsTable = new NgTableParams({
			page : 1,
			count : 5
		}, {
			total : $scope.data.length,
			getData : function($defer, params) {
				var temp = ctrl.metricsData;
				ctrl.title = "GCH API Usage Metrics";
				if(ctrl.metricsData.length > 0) {
					ctrl.env = ctrl.metricsData[0].env;
				}
				$scope.data = ctrl.metricsData.slice((params.page() - 1)* params.count(), params.page() * params.count());
				$scope.data = params.filter() ? $filter('filter')($scope.data, params.filter()) : $scope.data;
				
				ctrl.totalNoTrans = 0;
				var filterData = $filter('filter')(ctrl.metricsData, params.filter());
				for(var i =0; i< filterData.length; i++){
					ctrl.totalNoTrans = ctrl.totalNoTrans + parseInt(filterData[i].count);
				}
				ctrl.totalNoTrans = ctrl.totalNoTrans;
				
				$defer.resolve( $scope.data);
			}
		});

	}
})();