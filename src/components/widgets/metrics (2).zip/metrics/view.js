(function() {
	'use strict';

	angular.module(HygieiaConfig.module).controller('MetricsViewController',
			MetricsViewController);

	MetricsViewController.$inject = [ '$q', '$scope', 'metricsData', '$modal' ];
	function MetricsViewController($q, $scope, metricsData, $modal) {
		var ctrl = this;

		ctrl.metricsChartOptions = {
				 plugins: [
				Chartist.plugins.ctPointLabels({
                    textAnchor: 'middle'
                })
				],
				// Default mobile configuration
				  stackBars: true,
				  /*axisX: {
				    labelInterpolationFnc: function(value) {
				      return value.split(/\s+/).map(function(word) {
				        return word[0];
				      }).join('');
				    }
				  },*/
				  axisY: {
				    offset: 20
				  }
				
		};
		ctrl.showDetail = showDetail;
		ctrl.load = function() {
			var deferred = $q.defer();
			var params = {
				componentId : $scope.widgetConfig.componentId,
				numberOfDays : 14
			};
			metricsData.details(params).then(function(data) {
				processResponse(data.result, params.numberOfDays);
				deferred.resolve(data.lastUpdated);
			});
			return deferred.promise;
		};

		function showDetail() {
            $modal.open({
                controller: 'MetricsDetailController',
                controllerAs: 'metricsDetail',
                templateUrl: 'components/widgets/metrics/detail.html',
                size: 'lg',
                /*resolve: {
                    commits: function() {
                        return groupedCommitData[pointIndex];
                    }
                }*/
            });
        }
		
		
		function processResponse(data, numberOfDays) {
			var dataCollection = [];
			var countCollection = [];
			for (var i = 0; i < data.length; i++) {
				
				console.log(data[i].methodName);
				dataCollection.push(data[i].methodName);
				countCollection.push(data[i].count);
			}
			ctrl.metricsChartData = {
				labels : dataCollection,
				series : [ countCollection ]
			};
		}
	}
})();
