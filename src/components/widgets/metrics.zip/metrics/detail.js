(function() {
	'use strict';

	angular.module(HygieiaConfig.module).controller('MetricsDetailController',
			MetricsDetailController);

	MetricsDetailController.$inject = [ '$modalInstance', '$scope', '$filter',
			'NgTableParams' ];
	function MetricsDetailController($modalInstance, $scope,$filter,  NgTableParams) {
		/*jshint validthis:true */
		var ctrl = this;
		ctrl.metricsData = [

		{
			"serviceName" : "E2Ei",
			"methodName" : "getGCHProfiles",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "GCH",
			"count" : "10",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}, {
			"serviceName" : "E2Ei",
			"methodName" : "getCLINList",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "VECRM",
			"count" : "20",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}, {
			"serviceName" : "E2Ei",
			"methodName" : "getGCHProfileDetails",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "PQ",
			"count" : "30",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}, {
			"serviceName" : "E2Ei",
			"methodName" : "getGCHProfileDetails",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "PQ",
			"count" : "30",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}, {
			"serviceName" : "E2Ei",
			"methodName" : "getGCHProfileDetails",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "PQ",
			"count" : "30",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}, {
			"serviceName" : "E2Ei",
			"methodName" : "getGCHProfileDetails",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "PQ",
			"count" : "30",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}, {
			"serviceName" : "E2Ei",
			"methodName" : "getGCHProfileDetails",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "PQ",
			"count" : "30",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}, {
			"serviceName" : "E2Ei",
			"methodName" : "getGCHProfileDetails",
			"methodType" : "REST",
			"interfaceType" : "INTERNAL",
			"status" : "SUCCESS",
			"env" : "QA1",
			"client" : "PQ",
			"count" : "30",
			"id" : "56b905b29f034b44104d95af",
			"collectorItemId" : "56b905b29f034b44104d95ae",
			"timestamp" : 1454966194240
		}

		];

		ctrl.metricsTable = new NgTableParams({
			page : 1,
			count : 5
		}, {
			total : ctrl.metricsData.length,
			getData : function($defer, params) {
				$scope.data = ctrl.metricsData.slice((params.page() - 1)
						* params.count(), params.page() * params.count());
				$scope.data = params.filter() ? $filter('filter')(ctrl.metricsData, params.filter()) : ctrl.metricsData;
				$defer.resolve( $scope.data);
			}
		});

	}
})();